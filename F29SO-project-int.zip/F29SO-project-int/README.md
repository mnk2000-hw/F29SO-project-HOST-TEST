Here's quick documentation about frontend part of this project

...

you sure you want to know?<br>
╱ ╱▔▔▔▔▔▔▔╲<br>
 ╱         ╲<br>
 ▏      ╭  ▕<br>
▕╭━╮╮╭━╮┣╯ ▕<br>
▕┃▕▋┊┃▕▋╰╮  ▏<br>
▕╰━╭╮╰━╯ ╰┈ ▏<br>
▕▂╮┗┛ ╭┳┳┳╯▕<br>
^v^ ┳┳┳┳┳┫╰┃▂╱<br>
^v^▕╋╋╋╋┫┃▕╯<br>
^v^▕┻┻┻┻┻╯▕<br>
^v^▕▂▂▂▂▂▂╱<br>

ok then<br>

┊▕▔╲┊┊┊▇◣▂◢▇▔▏┊<br>
┊╱┈┈▔▔▔▇▇▇▇▇┈╲┊<br>
╱┈┈┈┈┈┈▇◤▔◥▇┈┈╲<br>
▏┈┈┈┈┈┈┈┈┈┈┈┈┈▕<br>
▏╱┈┈▇┈┈┈┈┈▇┈┈╲▕<br>
╲╱┈┈┈┈┈▅┈┈┈┈┈╲╱<br>
┊╱╲▂▂▂▂▂▂▂▂▂╱╲┊<br>

This file derictory consit 2 folders, frist one is representing react-native-app which is actual code of an app with all depedencies and other files
Second one is folder with just react basis code in case our team wanted to use it in terms of creating it not using pure html and css and made actual
project based on react itself but i dont think its going to be like that, well at least when im writing this i dont know, mb you guys in the future
see what we did as a team but anyways, who ever reading readme files, its like when your code doesnt work and you tried all possible solutions and
you go to readme file to find even small help lmao, anyways here's few folders of our hard wors so please enjoy it and youre welcome to say pleasent words
to us cuz we really tried our best, cuz nobody of us worked with this type of thing before so yeah <3

People who contributed in frontend is:

---

Nibras: Login and signup, Moods, zones <br>
Alex: Energy analysis, Devices<br>
Vir: Home, settings <br>

---

if you have any doubts, contact any member of our team (not only frontend team) to clarify any moments

A\_\_\_\_A<br>
|・ㅅ・| Meow<br>
|っ　ｃ|<br>
|　　　|<br>
|　　　|<br>
|　　　|<br>
|　　　|<br>
|　　　|<br>
|　　　| I Hope<br>
|　　　| You have<br>
|　　　| A nice Weekend! :3<br>
U ￣ ￣ U<br>
